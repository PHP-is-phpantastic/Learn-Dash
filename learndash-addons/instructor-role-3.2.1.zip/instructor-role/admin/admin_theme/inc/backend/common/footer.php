<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );
?>
</div><!-- <?php echo E_ADMIN_PLUGIN_PREFIX; ?>-admin-main-wrapper -->