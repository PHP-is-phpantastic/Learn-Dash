jQuery(document).ready(function($) {
	//$('body').addClass('eat-body-class-wrap eat-dashboard-temp-4')
});