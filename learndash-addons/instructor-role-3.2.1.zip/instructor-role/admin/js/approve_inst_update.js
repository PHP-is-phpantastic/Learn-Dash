var el = wp.element.createElement;
var __ = wp.i18n.__;
var registerPlugin = wp.plugins.registerPlugin;
var PluginPostStatusInfo = wp.editPost.PluginPostStatusInfo;
var Button = wp.components.Button;

registerPlugin( 'instructor-role', {
	render: add_button_to_approve
} );

function add_button_to_approve() {
    return el(
            PluginPostStatusInfo,
            {
                className: 'approve_instructor_update'
            },
            el(
                Button,
                {
                    isDefault: true,
                    target: '#',
                    onClick: alert_to_approve
                },
                test_object.button_text
            )
    );
}
function alert_to_approve(event)
{
    var txt;
    var r = confirm(test_object.confirmation_message);
    if (r == true) {
      send_ajax();
    }
}
function send_ajax()
{
    jQuery.ajax({
        url: test_object.ajax_url,
        type: 'POST',
        data: {"action":"approve_instructor_update_ajax", "post_id":test_object.post_id},
        success: function(response, textStatus, jqXHR) {
            if (response == 'approved') {
                jQuery("div.approve_instructor_update").remove();
                alert(test_object.successfull_message);
            } else {
                alert(response);
            }
        }
    });
}