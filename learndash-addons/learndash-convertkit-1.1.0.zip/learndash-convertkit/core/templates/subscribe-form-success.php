<?php
/**
 * Subscription Form Success Message for LearnDash ConvertKit
 *
 * This can be overridden by the Theme under ./learndash-convertkit/subscribe-form-success.php
 *
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || die();
?>

<div class="ld-convertkit-subscribe-form ld-convertkit-subscribe-form-success">
    <p>
        <?php _e( 'You have successfully been subscribed! Please check your email to confirm your subscription.', 'learndash-convertkit' ); ?>
    </p>
</div>