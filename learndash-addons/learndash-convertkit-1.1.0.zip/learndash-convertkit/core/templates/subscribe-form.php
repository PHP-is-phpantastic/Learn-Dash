<?php
/**
 * Subscription Form for LearnDash ConvertKit
 *
 * This can be overridden by the Theme under ./learndash-convertkit/subscribe-form.php
 *
 * @since 1.0.0
 *
 * @var int $course_id
 */

defined( 'ABSPATH' ) || die(); ?>

<div class="ld-convertkit-subscribe-form">
    <form action="" method="post">

        <input type="hidden" name="ld_convertkit_course_id" value="<?php echo $course_id; ?>">
		<?php wp_nonce_field( "ld_convertkit_subscribe_course_id_$course_id", 'ld_convertkit_subscribe_course_nonce' ); ?>

        <input type="submit" name="ld_convertkit_submit_subscribed"
               value="<?php _e( 'Subscribe', 'learndash-convertkit' ); ?>"/>

    </form>
</div>