<?php
/**
 * Subscription Form Failed Message for LearnDash ConvertKit
 *
 * This can be overridden by the Theme under ./learndash-convertkit/subscribe-form-success.php
 *
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || die();
?>

<div class="ld-convertkit-subscribe-form ld-convertkit-subscribe-form-failed">
	<p>
		<?php _e( 'Something went wrong. Please try again later.', 'learndash-convertkit' ); ?>
	</p>
</div>