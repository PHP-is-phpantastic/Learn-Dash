=== LearnDash - ConvertKit ===
Contributors: joelworsham
Requires at least: 4.0.0
Tested up to: 4.9.2
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds ConvertKit integration to LearnDash LMS.

== Description ==

Adds ConvertKit integration to LearnDash LMS.

== Changelog ==

= 1.1.1 =
* If Auto-Subscribe is enabled, Tags Students for the relevant Courses when they are added to a Group
* Fixes an issue with checking whether a Student is already subscribed to the Form when the Form has a large number of subscribers

= 1.1.0 =
* Add auto-subscribe.

= 1.0.0 =
* First release.