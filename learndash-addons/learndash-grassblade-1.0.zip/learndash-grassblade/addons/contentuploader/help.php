<script>
/*function getOffset( el ) {
    var _x = 0;
    var _y = 0;
    while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
        _x += el.offsetLeft - el.scrollLeft;
        _y += el.offsetTop - el.scrollTop;
        el = el.offsetParent;
    }
    return { top: _y, left: _x };
}*/
function showHideOptional(id) {
	var table = document.getElementById(id);
	var display_status = table.style.display;

	
	if(display_status == "none")
	{
		table.style.display = "block";
		//window.scrollTo(getOffset(table).left,getOffset(table).top);
	}
	else
		table.style.display = "none";
		
	//return false;
}
</script>

<style>
.infoblocks {
	background: greenyellow;
	border: 1px solid black;
	display: block;
	padding: 10px 20px;
}

</style>
<h2 name="xapi_content">xAPI Content Manager - <small><a style="color:red" href="http://www.nextsoftwaresolutions.com/grassblade-xapi-companion/" target="_blank">Get It Now</a></small></h2>

<a href="#xapi_content" onclick="return showHideOptional('grassblade_cu_howto');"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">How to upload an xAPI (Tin Can) content package from Articualate or other provider?</span></h3></a>
<div id="grassblade_cu_howto"  class="infoblocks"  style="display:none;">
<p>
xAPI Content menu option can be used to upload xAPI Content zip Package. You have to click on 'Add New' under 'xAPI Content' menu option. Write a title, select the zip package using uploader, select the version and hit publish. Simple!<br><br>
You can test the upload using the View button next to launch url<br><br>
Use the provided shortcode, or the Launch Url as the SRC parameter in the shortcode generator to add the content to the page, post or courses you want to add it to.<br><br>
Make sure you are using the right version. e.g. For a 0.90 Articulate Content you need to select 0.90 in both content uploader, and the shortcode. 

</p>
</div>
<a href="#xapi_nonxapicontent" onclick="return showHideOptional('grassblade_cu_nonxapi');"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">Can I upload Non Tin Can content package from Articulate or other provider?</span></h3></a>
<div id="grassblade_cu_nonxapi"  class="infoblocks"  style="display:none;">
<p>
Currently you can upload Articulate Studio packages using xAPI Content Upload tool. PageViews can be tracked for such packages if you have PageViews feature enabled on your GrassBlade version. Please contact us if you need support for more packages.

</p>
</div>