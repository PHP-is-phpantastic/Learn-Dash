<?php
define('GBL_LEARNDASH_PLUGIN_FILE', 'sfwd-lms/sfwd_lms.php');
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if(is_plugin_active(GBL_LEARNDASH_PLUGIN_FILE))
{
	add_action('admin_menu', 'grassblade_learndash_menu', 1);
}

function grassblade_learndash_menu() {
	add_submenu_page("edit.php?post_type=sfwd-courses", "TinCan Settings", "TinCan Settings",'manage_options','admin.php?page=grassblade-lrs-settings', 'grassblade_menu_page');
//	add_submenu_page("edit.php?post_type=sfwd-courses", "PageViews Settings", "PageViews Settings",'manage_options','admin.php?page=pageviews-settings', 'grassblade_pageviews_menupage');
	//add_submenu_page("edit.php?post_type=sfwd-courses", "One Click Upload", "One Click Upload",'manage_options',get_admin_url(null, "edit.php?post_type=gb_xapi_content"), 'grassblade_menu_page');	

}


function grassblade_learndash_trackable_taxonomies($taxonomies) {
	if(!in_array('courses',$taxonomies))
	$taxonomies[] = 'courses';
	
	return $taxonomies;
}
add_filter('grassblade_trackable_taxonomies', 'grassblade_learndash_trackable_taxonomies',1,1);