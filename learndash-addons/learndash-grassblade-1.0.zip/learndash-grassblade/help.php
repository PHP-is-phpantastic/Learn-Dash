<script>
/*function getOffset( el ) {
    var _x = 0;
    var _y = 0;
    while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
        _x += el.offsetLeft - el.scrollLeft;
        _y += el.offsetTop - el.scrollTop;
        el = el.offsetParent;
    }
    return { top: _y - 500, left: _x };
}*/
function showHideOptional(id) {
	var table = document.getElementById(id);
	var display_status = table.style.display;

	
	if(display_status == "none")
	{
		table.style.display = "block";
		//window.scrollTo(getOffset(table).left,getOffset(table).top);
	}
	else
		table.style.display = "none";
		
	//return false;
}
</script>
<style>
.infoblocks {
	background: greenyellow;
	border: 1px solid black;
	display: block;
	padding: 10px 20px;
}

</style>
<h2 name="grassblade_help_faq">Help FAQ</h2>

<a href="#grassblade_help_faq" onclick="return showHideOptional('grassblade_whatfor');" name="grassblade_whatfor"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">What can GrassBlade be used for?</span></h3></a>
<div id="grassblade_whatfor"  class="infoblocks"  style="display:none;">
<p>
1. You can use it for launching TinCan content from wordpress, and track user activity on your LRS.
<br>
2. GrassBlade can track and send statements for common activities like page views to your LRS.
<br>
</p>
</div>


<a href="#grassblade_help_faq" onclick="return showHideOptional('grassblade_userpass');" name="grassblade_userpass"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">Where will I get the endpoint url, user and password from?</span></h3></a>
<div id="grassblade_userpass"  class="infoblocks"  style="display:none;">
<p>These details are provided by your LRS. If you are using Scorm Cloud from Rustici or WaxLRS. The following details can help:<br>
<br>
<b>Configuring GrassBlade with Scorm Cloud</b><br>
1. Create an application in Scorm Cloud. Get the Application ID and Secret.<br>
2. In GrassBlade Settings you will have to enter the following details:<br>
<b>Endpoint URL:</b> https://cloud.scorm.com/ScormEngineInterface/TCAPI/<b>&lt;APPLICATIONID&gt;</b>/<br>
<b>User:</b> <b>&lt;APPLICATIONID&gt;</b><br>
<b>Password:</b> <b>&lt;APPLICATION SECRET&gt;</b><br><br>

<b>Configuring GrassBlade with WaxLRS</b><br>
1. Go to Settings.<br>
2. Under 'Basic Credentials' click on 'New Basic Credentials'.<br>
<b>Endpoint URL:</b> Endpoint as mentioned on the settings page e.g. https://&lt;yourcompany&gt;.waxlrs.com/TCAPI/<br>
<b>User:</b> <b>&lt;APPLICATIONID&gt;</b><br>
<b>Password:</b> <b>&lt;APPLICATION SECRET&gt;</b><br><br>

<br>
</p>
</div>



<a href="#grassblade_userpass" onclick="return showHideOptional('grassblade_scgen');" name="grassblade_scgen"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">Shortcode Generator - What is easiest way to add grassblade shortcode?</span></h3></a>
<div id="grassblade_scgen"  class="infoblocks"  style="display:none;">
<p>You can generate shortcode using the GrassBlade Shortcode Generator. Click the button with GrassBlade icon <img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button2.png"; ?>" height="15px"/> on the WYSIWYG editor when creating a page.<br><br>
<img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/GrassBladeWYSIWYG.jpg"; ?>"/>
<br>
</p>
</div>


<a href="#grassblade_userpass" onclick="return showHideOptional('grassblade_example_usage');"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">What are the example usage?</span></h3></a>
<div id="grassblade_example_usage"  class="infoblocks"  style="display:none;">
<p>
1. <b>[grassblade src='http://www.nextsoftwaresolutions.com/demo/articulate/story.html']</b>: This will launch the page url http://www.nextsoftwaresolutions.com/demo/articulate/story.html in a 960 X 640px iframe<br>
<br>
2. <b>[grassblade src='http://www.nextsoftwaresolutions.com/demo/articulate/story.html' width='900px' height='600px']</b>: This will launch the page url http://www.nextsoftwaresolutions.com/demo/articulate/story.html in a 900 X 600px iframe
<br>
<br>
3. <b>[grassblade src='http://www.nextsoftwaresolutions.com/demo/articulate/story.html' width='900px' height='600px' endpoint='https://mylrsendpoint.com' user='myauthuser' pass='myauthpass']</b>: Using endpoint details for the tag instead of using them from this settings page. This is for being able to use diffenent LRS for different pieces of content.
</p>
</div>

<a href="#grassblade_userpass" onclick="return showHideOptional('grassblade_parameters');"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">What parameters can be used in the shortcode?</span></h3></a>
<div id="grassblade_parameters"  class="infoblocks" style="display:none;">
<p>
1. <b>src</b>*: (Required) . This URL of content's launch page where the content is to be accessed.
<br>
2. <b>width</b>: Optional. Default 940px. Width is the iframe width for the content in which content is launched.
<br>
3. <b>height</b>: Optional. Default 640px. Height is the iframe height for the content in which content is launched.
<br>
4. <b>endpoint</b>: Optional. Default is the value of LRS endpoint on this page.
<br>
5. <b>user</b>: Optional. Default is the value of User on this page.
<br>
6. <b>pass</b>: Optional. Default is the value if Password on this page.
<br>
7. <b>Version</b>: Optional. Default <b>0.95</b>. If using 0.90 content, set the version to 0.90
<br>
8. <b>target</b>: Optional. Default <b>iframe</b>. Use target='_blank' to open in new window.
<br>
9. <b>guest</b>: Optional. Default <b>is the setting on this page.</b>. Set to 1 or 0 to allow or disable guest access for specific content.
<br>
10. <b>activity_id</b>: Optional. This should be a URL unique to your content/activity.

</p>

</div>

<a href="#grassblade_userpass" onclick="return showHideOptional('grassblade_guest');"><h3><img src="<?php echo get_bloginfo('wpurl')."/wp-content/plugins/grassblade/img/button.png"; ?>"/><span style="margin-left:10px;">How does Guest tracking work?</span></h3></a>
<div id="grassblade_guest"  class="infoblocks"  style="display:none;">
<p>
Guest Tracking feature is to be able to track activities of users who are not logged in. Just for tracking purposes, Name and Email will be decided as mentioned in the grassblade settings page.
</p>
</div>
<?php
$GrassBladeAddons = new GrassBladeAddons();
$GrassBladeAddons->IncludeHelpFiles();
?>
<br>
<br> 
<h2>Need More Features?</h2>
<p>
Contact us if you need more features, custom reports or want any customizations to GrassBlade.<br><br>
<b>Email:</b> <a href="mailto:contact@nextsoftwaresolutions.com" target="_blank">contact@nextsoftwaresolutions.com</a><br><br>
<b>Contact Page:</b> <a href="http://www.nextsoftwaresolutions.com/contact-us/"  target="_blank">http://www.nextsoftwaresolutions.com/contact-us/</a><br>
</p>
