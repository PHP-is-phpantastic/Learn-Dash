=== GrassBlade xAPI Companion ===
Tags: GrassBlade, Tin Can API, xAPI, Experience API
Requires at least: 2.8
Tested up to: 3.5.1
Contributors: Pankaj Agrawal
Donate link:https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=contact%40pankajagrawal%2ecom&item_name=GrassBlade%20Donation&no_shipping=0&no_note=1&tax=0&currency_code=USD&lc=US&bn=PP%2dDonationsBF&charset=UTF%2d8

First Tin Can Plugin on Wordpress. Host Tin Can API Content on Wordpress, track user data. Supports packages from Articulate, Lectora, DominKnow, iSpring and more.

== Description ==

#### GrassBlade - xAPI Companion 

GrassBlade - xAPI Companion is a support tool for Experience API (xAPI) or Tin Can API. It can launch content inside an iframe by providing necessary parameters in the url. We have tested it tincan content published using Articulate and with demos provided by ADL. It can also send tracking statements to the LRS on Page View. (Free Version has limited features.)

#### Features:
* One Click Content Upload
* Embed Tin Can package in wordpress post, pages, or custom posts. 
* Add Launch Link
* Statement Viewer

#### Supports Tin Can Packages:
* Articulate Storyline
* Lectora Inspire
* DominKnow Claro
* iSpring Pro, and more

#### Supports Non-Tin Can Packages:
* Articulate Studio


== Changelog ==

= 0.4.0 =
* Fix support for Articulate Storline after their changes.
* Added support for DominKnow Calro Tin Can package
* Added support for Lectora Inspire Tin Can package
* Added support for iSpring Tin Can package
* Added Statement Viewer
* Added activity_id
* Added target options to be able to choose from embeding content in page, or a Launch link.

= 0.3.0 =
* Added One click upload 

= 0.2.0 
* Added short code generator

= 0.1.0 =
* Launch!