import FieldsInitialize from "./fields-init";

// Initialize app on jQuery Ready.
jQuery(() => {

    const Fields = new FieldsInitialize(jQuery(document));
});