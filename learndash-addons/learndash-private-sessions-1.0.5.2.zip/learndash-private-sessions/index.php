<?php
/* Silence is golden */
