<ul id="sidemenu">
	<li id="tab-upload" class="current"><a href="#" data-id="upload_file"><?php _e( 'Upload File', 'uncanny-learndash-reporting' ); ?></a> </li>
	<li id="tab-snc-library"><a href="#" data-id="library"><?php _e( 'Content Library', 'uncanny-learndash-reporting' ); ?></a></li>
</ul>
<div class="clear"></div>
