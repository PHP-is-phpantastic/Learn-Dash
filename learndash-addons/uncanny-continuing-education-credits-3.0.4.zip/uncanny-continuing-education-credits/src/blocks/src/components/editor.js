export const UcecPlaceholder = ({ children }) => {
	return (
		<div className="uo-ucec-placeholder">
			{ children }
		</div>
	);
}